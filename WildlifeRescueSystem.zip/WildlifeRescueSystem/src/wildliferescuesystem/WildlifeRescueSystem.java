package wildliferescuesystem;

import java.util.Scanner;

/**
 * Main Class: WildlifeRescueSystem
 */
public class WildlifeRescueSystem {

    private static final Scanner scanner = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();

    public static void main(String[] args) {
        // Pre-populating sample cases
        manager.addRescueCase(new InjuredAnimalRescue(
            "WR101", "Elephant Bull", "African Elephant", "Kruger National Park",
            "John Ndlovu", 5, 1500.0, "Rescue in Progress",
            "Poacher snare wound on front leg", 8000.0, true
        ));

        manager.addRescueCase(new OrphanedAnimalRescue(
            "WR102", "Little Rhino", "White Rhino", "Hluhluwe Imfolozi",
            "Sarah Khoza", 10, 600.0, "Under Observation",
            4, 3000.0, true
        ));

        boolean running = true;

        while (running) {
            displayMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    handleCreateRescueCase();
                    break;
                case "2":
                    handleSearchRescueCase();
                    break;
                case "3":
                    handleUpdateRescueStatus();
                    break;
                case "4":
                    handleDisplayAllCases();
                    break;
                case "5":
                    System.out.println(manager.generateFullReport());
                    break;
                case "6":
                    System.out.println("\nExiting Wildlife Rescue Operations System. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("\n[Error] Invalid choice. Please select an option from 1 to 6.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\n=========================================");
        System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("=========================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
        System.out.print("\nSelect an option: ");
    }

    private static void handleCreateRescueCase() {
        System.out.println("\n--- CREATE NEW RESCUE CASE ---");
        System.out.println("Select Rescue Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");
        System.out.print("Enter type option (1-3): ");
        String typeChoice = scanner.nextLine().trim();

        if (!typeChoice.equals("1") && !typeChoice.equals("2") && !typeChoice.equals("3")) {
            System.out.println("[Error] Invalid rescue type selection.");
            return;
        }

        String caseId;
        while (true) {
            System.out.print("Enter Rescue Case ID: ");
            caseId = scanner.nextLine().trim();
            if (caseId.isEmpty()) {
                System.out.println("[Error] Case ID cannot be blank.");
            } else if (!manager.isCaseIdUnique(caseId)) {
                System.out.println("[Error] Case ID '" + caseId + "' already exists. It must be unique.");
            } else {
                break;
            }
        }

        String animalName = readNonEmptyString("Enter Animal Name: ");
        String species = readNonEmptyString("Enter Species: ");
        String location = readNonEmptyString("Enter Rescue Location: ");
        String ranger = readNonEmptyString("Enter Assigned Ranger: ");
        int days = readPositiveInt("Enter Number of Rescue Days: ");
        double dailyCost = readPositiveDouble("Enter Daily Care Cost (R): ");
        String status = "Pending";

        RescueCase newCase = null;

        if (typeChoice.equals("1")) {
            String injury = readNonEmptyString("Enter Injury Description: ");
            double vetCost = readPositiveDouble("Enter Veterinary Treatment Cost (R): ");
            boolean surgery = readBoolean("Is Surgery Required? (Y/N): ");
            newCase = new InjuredAnimalRescue(caseId, animalName, species, location, ranger, days, dailyCost, status, injury, vetCost, surgery);
        } else if (typeChoice.equals("2")) {
            int ageMonths = readPositiveInt("Enter Estimated Age in Months: ");
            double feedingCost = readPositiveDouble("Enter Feeding Cost (R): ");
            boolean fosterCare = readBoolean("Is Foster Care Required? (Y/N): ");
            newCase = new OrphanedAnimalRescue(caseId, animalName, species, location, ranger, days, dailyCost, status, ageMonths, feedingCost, fosterCare);
        } else if (typeChoice.equals("3")) {
            String classification = readNonEmptyString("Enter Conservation Classification: ");
            double securityCost = readPositiveDouble("Enter Security Cost (R): ");
            boolean specialist = readBoolean("Is Specialist Team Required? (Y/N): ");
            newCase = new EndangeredSpeciesRescue(caseId, animalName, species, location, ranger, days, dailyCost, status, classification, securityCost, specialist);
        }

        if (manager.addRescueCase(newCase)) {
            System.out.println("\nSUCCESS: Rescue case created successfully!");
        } else {
            System.out.println("\n[Error] Failed to add rescue case.");
        }
    }

    private static void handleSearchRescueCase() {
        System.out.print("\nEnter Rescue Case ID to search: ");
        String searchId = scanner.nextLine().trim();
        RescueCase rc = manager.searchRescueCase(searchId);

        if (rc != null) {
            System.out.println("\n--- CASE FOUND ---");
            System.out.print(rc.generateRescueSummary());
        } else {
            System.out.println("\n[Notice] No rescue case found with ID: " + searchId);
        }
    }

    private static void handleUpdateRescueStatus() {
        System.out.print("\nEnter Rescue Case ID to update status: ");
        String caseId = scanner.nextLine().trim();
        RescueCase rc = manager.searchRescueCase(caseId);

        if (rc == null) {
            System.out.println("[Error] No rescue case found with ID: " + caseId);
            return;
        }

        System.out.println("Current Status: " + rc.getCurrentRescueStatus());
        System.out.println("1. Start Rescue Operation (Status -> Rescue in Progress)");
        System.out.println("2. Complete Rescue Operation (Status -> Completed)");
        System.out.println("3. Enter Custom Status");
        System.out.print("Select option (1-3): ");
        String option = scanner.nextLine().trim();

        switch (option) {
            case "1":
                rc.startRescueOperation();
                System.out.println("Status updated to: " + rc.getCurrentRescueStatus());
                break;
            case "2":
                rc.completeRescueOperation();
                System.out.println("Status updated to: " + rc.getCurrentRescueStatus());
                break;
            case "3":
                String custom = readNonEmptyString("Enter new status: ");
                manager.updateRescueStatus(caseId, custom);
                System.out.println("Status updated to: " + custom);
                break;
            default:
                System.out.println("[Notice] Invalid selection. Status remains unchanged.");
        }
    }

    private static void handleDisplayAllCases() {
        if (manager.getRescueCases().isEmpty()) {
            System.out.println("\nNo rescue cases to display.");
            return;
        }
        System.out.println("\n--- ALL RESCUE CASES ---");
        for (RescueCase rc : manager.getRescueCases()) {
            System.out.print(rc.generateRescueSummary());
        }
    }

    private static String readNonEmptyString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) return input;
            System.out.println("[Error] Input cannot be blank. Please try again.");
        }
    }

    private static int readPositiveInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value > 0) return value;
                System.out.println("[Error] Value must be greater than 0.");
            } catch (NumberFormatException e) {
                System.out.println("[Error] Please enter a valid integer number.");
            }
        }
    }

    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (value >= 0) return value;
                System.out.println("[Error] Value cannot be negative.");
            } catch (NumberFormatException e) {
                System.out.println("[Error] Please enter a valid decimal number.");
            }
        }
    }

    private static boolean readBoolean(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim().toUpperCase();
            if (input.equals("Y") || input.equals("YES")) return true;
            if (input.equals("N") || input.equals("NO")) return false;
            System.out.println("[Error] Please enter 'Y' for Yes or 'N' for No.");
        }
    }
}