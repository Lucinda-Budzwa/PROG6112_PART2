package wildliferescuesystem;

public interface IRescueOperations {
    void startRescueOperation();
    void completeRescueOperation();
    String generateRescueSummary();
}