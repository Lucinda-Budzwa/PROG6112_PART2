package wildliferescuesystem;

/**
 * Subclass: OrphanedAnimalRescue
 * 
 * Concept: Inheritance & Method Overriding
 * Handles young, orphaned wildlife requiring feeding and foster care.
 */
public class OrphanedAnimalRescue extends RescueCase {

    // Specific attributes
    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    // Fixed constant surcharge for foster care assistance
    public static final double FOSTER_CARE_SURCHARGE = 2500.00;

    /**
     * Constructor calls the parent superconstructor and initializes specialized fields.
     */
    public OrphanedAnimalRescue(String caseId, String animalName, String species, 
                                String rescueLocation, String assignedRanger, 
                                int numberOfRescueDays, double dailyCareCost, 
                                String currentRescueStatus, int estimatedAgeMonths, 
                                double feedingCost, boolean fosterCareRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, 
              numberOfRescueDays, dailyCareCost, currentRescueStatus);
        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    /**
     * Total cost formula:
     * (Daily Care Cost * Days) + Feeding Cost + (Foster Care Required ? R2 500 : R0)
     */
    @Override
    public double calculateTotalCost() {
        double baseCost = getNumberOfRescueDays() * getDailyCareCost();
        double extraFoster = fosterCareRequired ? FOSTER_CARE_SURCHARGE : 0.0;
        return baseCost + feedingCost + extraFoster;
    }

    /**
     * Determines priority: High if under 6 months old; Medium otherwise.
     */
    @Override
    public String determinePriority() {
        return (estimatedAgeMonths <= 6) ? "High" : "Medium";
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    // Getters and Setters
    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public void setEstimatedAgeMonths(int estimatedAgeMonths) {
        this.estimatedAgeMonths = estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public void setFeedingCost(double feedingCost) {
        this.feedingCost = feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }

    public void setFosterCareRequired(boolean fosterCareRequired) {
        this.fosterCareRequired = fosterCareRequired;
    }
}
