package wildliferescuesystem;

/**
 * Abstract Class: RescueCase
 * 
 * Concepts: Abstraction, Encapsulation, Inheritance, and Interfaces
 * Serves as the base parent class for all specialized types of rescue operations.
 * Implements IRescueOperations and encapsulates common attributes shared by all rescues.
 */
public abstract class RescueCase implements IRescueOperations {

    // ==========================================
    // ENCAPSULATION: Private attributes
    // ==========================================
    private String caseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private String currentRescueStatus;

    /**
     * Parameterized Constructor for the base rescue case.
     */
    public RescueCase(String caseId, String animalName, String species, 
                      String rescueLocation, String assignedRanger, 
                      int numberOfRescueDays, double dailyCareCost, 
                      String currentRescueStatus) {
        this.caseId = caseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;
        this.currentRescueStatus = currentRescueStatus;
    }

    // ==========================================
    // ABSTRACTION: Abstract methods for subclasses
    // ==========================================
    
    /**
     * Calculates the total cost of the rescue based on subclass-specific formulas.
     * @return double representing the total rescue cost
     */
    public abstract double calculateTotalCost();

    /**
     * Determines the operational priority (e.g. Critical, High, Medium).
     * @return String priority level
     */
    public abstract String determinePriority();

    /**
     * Returns the user-friendly name of the rescue classification type.
     * @return String rescue type description
     */
    public abstract String getRescueType();

    // ==========================================
    // INTERFACE METHOD IMPLEMENTATIONS
    // ==========================================

    @Override
    public void startRescueOperation() {
        // Updates state to indicate rescue is underway
        this.currentRescueStatus = "Rescue in Progress";
    }

    @Override
    public void completeRescueOperation() {
        // Updates state to indicate operation is completed
        this.currentRescueStatus = "Completed";
    }

    @Override
    public String generateRescueSummary() {
        // Formats output matching the assignment brief specification
        StringBuilder sb = new StringBuilder();
        sb.append("-----------------------------------------\n");
        sb.append(String.format("%-16s: %s\n", "Case ID", getCaseId()));
        sb.append(String.format("%-16s: %s\n", "Type", getRescueType()));
        sb.append(String.format("%-16s: %s\n", "Species", getSpecies()));
        sb.append(String.format("%-16s: %s\n", "Assigned Ranger", getAssignedRanger()));
        sb.append(String.format("%-16s: %s\n", "Priority", determinePriority()));
        sb.append(String.format("%-16s: %s\n", "Status", getCurrentRescueStatus()));
        sb.append(String.format("%-16s: R%,.2f\n", "Total Cost", calculateTotalCost()));
        return sb.toString();
    }

    // ==========================================
    // GETTERS AND SETTERS (Encapsulation)
    // ==========================================

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public void setRescueLocation(String rescueLocation) {
        this.rescueLocation = rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public void setAssignedRanger(String assignedRanger) {
        this.assignedRanger = assignedRanger;
    }

    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }

    public void setNumberOfRescueDays(int numberOfRescueDays) {
        this.numberOfRescueDays = numberOfRescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public void setDailyCareCost(double dailyCareCost) {
        this.dailyCareCost = dailyCareCost;
    }

    public String getCurrentRescueStatus() {
        return currentRescueStatus;
    }

    public void setCurrentRescueStatus(String currentRescueStatus) {
        this.currentRescueStatus = currentRescueStatus;
    }
}