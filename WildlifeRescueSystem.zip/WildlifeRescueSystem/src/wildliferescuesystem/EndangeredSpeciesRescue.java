package wildliferescuesystem;

/**
 * Subclass: EndangeredSpeciesRescue
 * 
 * Concept: Inheritance & Method Overriding
 * Handles vulnerable and endangered wildlife requiring armed security and specialized handling.
 */
public class EndangeredSpeciesRescue extends RescueCase {

    // Specific attributes
    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    // Fixed constant surcharge for specialist deployment
    public static final double SPECIALIST_SURCHARGE = 8000.00;

    /**
     * Constructor calls the parent superconstructor and initializes specialized fields.
     */
    public EndangeredSpeciesRescue(String caseId, String animalName, String species, 
                                   String rescueLocation, String assignedRanger, 
                                   int numberOfRescueDays, double dailyCareCost, 
                                   String currentRescueStatus, String conservationClassification, 
                                   double securityCost, boolean specialistTeamRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, 
              numberOfRescueDays, dailyCareCost, currentRescueStatus);
        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    /**
     * Total cost formula:
     * (Daily Care Cost * Days) + Security Cost + (Specialist Team Required ? R8 000 : R0)
     */
    @Override
    public double calculateTotalCost() {
        double baseCost = getNumberOfRescueDays() * getDailyCareCost();
        double extraSpecialist = specialistTeamRequired ? SPECIALIST_SURCHARGE : 0.0;
        return baseCost + securityCost + extraSpecialist;
    }

    /**
     * Determines priority: Critical if critically endangered or specialist needed; High otherwise.
     */
    @Override
    public String determinePriority() {
        if ("Critically Endangered".equalsIgnoreCase(conservationClassification) || specialistTeamRequired) {
            return "Critical";
        }
        return "High";
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    // Getters and Setters
    public String getConservationClassification() {
        return conservationClassification;
    }

    public void setConservationClassification(String conservationClassification) {
        this.conservationClassification = conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public void setSecurityCost(double securityCost) {
        this.securityCost = securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }

    public void setSpecialistTeamRequired(boolean specialistTeamRequired) {
        this.specialistTeamRequired = specialistTeamRequired;
    }
}