package wildliferescuesystem;

/**
 * Subclass: InjuredAnimalRescue
 * 
 * Concept: Inheritance & Method Overriding
 * Handles animals requiring clinical treatment and potential surgery.
 */
public class InjuredAnimalRescue extends RescueCase {

    // Specific attributes
    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    // Fixed constant surcharge for surgical procedures as per brief
    public static final double SURGERY_SURCHARGE = 5000.00;

    /**
     * Constructor calls the parent superconstructor and initializes specialized fields.
     */
    public InjuredAnimalRescue(String caseId, String animalName, String species, 
                               String rescueLocation, String assignedRanger, 
                               int numberOfRescueDays, double dailyCareCost, 
                               String currentRescueStatus, String injuryDescription, 
                               double veterinaryTreatmentCost, boolean surgeryRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, 
              numberOfRescueDays, dailyCareCost, currentRescueStatus);
        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    /**
     * Total cost formula:
     * (Daily Care Cost * Days) + Veterinary Treatment Cost + (Surgery Required ? R5 000 : R0)
     */
    @Override
    public double calculateTotalCost() {
        double baseCost = getNumberOfRescueDays() * getDailyCareCost();
        double extraSurgery = surgeryRequired ? SURGERY_SURCHARGE : 0.0;
        return baseCost + veterinaryTreatmentCost + extraSurgery;
    }

    /**
     * Determines priority: Critical if surgery is required; High otherwise.
     */
    @Override
    public String determinePriority() {
        return surgeryRequired ? "Critical" : "High";
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    // Getters and Setters
    public String getInjuryDescription() {
        return injuryDescription;
    }

    public void setInjuryDescription(String injuryDescription) {
        this.injuryDescription = injuryDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public void setVeterinaryTreatmentCost(double veterinaryTreatmentCost) {
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }

    public void setSurgeryRequired(boolean surgeryRequired) {
        this.surgeryRequired = surgeryRequired;
    }
}
