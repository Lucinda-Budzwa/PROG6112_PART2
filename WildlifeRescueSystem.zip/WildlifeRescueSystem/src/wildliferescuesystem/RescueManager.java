package wildliferescuesystem;

import java.util.ArrayList;

/**
 * Controller Class: RescueManager
 * 
 * Concept: Polymorphism and Collection Management
 * Manages the ArrayList of RescueCase objects, validates uniqueness of IDs,
 * performs lookups, updates statuses, and aggregates financial data.
 */
public class RescueManager {

    // Store all rescue cases polymorphically in an ArrayList
    private final ArrayList<RescueCase> rescueCases;

    public RescueManager() {
        this.rescueCases = new ArrayList<>();
    }

    /**
     * Retrieves the list of all rescue cases.
     * @return ArrayList of RescueCase
     */
    public ArrayList<RescueCase> getRescueCases() {
        return rescueCases;
    }

    /**
     * Validates that a Rescue Case ID is unique and not blank.
     * 
     * @param caseId Case ID to validate
     * @return true if ID is unique and valid; false otherwise
     */
    public boolean isCaseIdUnique(String caseId) {
        if (caseId == null || caseId.trim().isEmpty()) {
            return false;
        }
        for (RescueCase rc : rescueCases) {
            if (rc.getCaseId().equalsIgnoreCase(caseId.trim())) {
                return false; // Found matching ID: not unique
            }
        }
        return true;
    }

    /**
     * Adds a new rescue case if the ID is unique.
     * 
     * @param rescueCase The rescue case to be added
     * @return true if successfully added; false otherwise
     */
    public boolean addRescueCase(RescueCase rescueCase) {
        if (rescueCase == null) return false;
        if (!isCaseIdUnique(rescueCase.getCaseId())) return false;
        return rescueCases.add(rescueCase);
    }

    /**
     * Searches for a rescue case by its unique ID.
     * 
     * @param caseId The ID to search for
     * @return Matching RescueCase object or null if not found
     */
    public RescueCase searchRescueCase(String caseId) {
        if (caseId == null || caseId.trim().isEmpty()) return null;
        for (RescueCase rc : rescueCases) {
            if (rc.getCaseId().equalsIgnoreCase(caseId.trim())) {
                return rc;
            }
        }
        return null;
    }

    /**
     * Updates the status of an existing rescue case.
     * 
     * @param caseId Case ID to update
     * @param newStatus New status value
     * @return true if update was successful; false if not found or invalid
     */
    public boolean updateRescueStatus(String caseId, String newStatus) {
        RescueCase rc = searchRescueCase(caseId);
        if (rc != null && newStatus != null && !newStatus.trim().isEmpty()) {
            rc.setCurrentRescueStatus(newStatus.trim());
            return true;
        }
        return false;
    }

    /**
     * Polymorphically calculates the sum of all rescue costs.
     * @return Total estimated cost across all cases
     */
    public double calculateTotalReportCost() {
        double total = 0;
        for (RescueCase rc : rescueCases) {
            total += rc.calculateTotalCost(); // Dynamic method dispatch (Polymorphism)
        }
        return total;
    }

    /**
     * Generates the complete formatted report matching the assignment brief.
     * @return Formatted report String
     */
    public String generateFullReport() {
        if (rescueCases.isEmpty()) {
            return "\nNo rescue cases currently recorded in the system.\n";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("\n=========================================\n");
        sb.append("WILDLIFE RESCUE REPORT\n");
        sb.append("=========================================\n");

        for (RescueCase rc : rescueCases) {
            sb.append(rc.generateRescueSummary());
        }

        sb.append("-----------------------------------------\n");
        sb.append(String.format("Total Rescue Cases : %d\n", rescueCases.size()));
        sb.append(String.format("Total Rescue Cost  : R%,.2f\n", calculateTotalReportCost()));
        sb.append("=========================================\n");

        return sb.toString();
    }
}
