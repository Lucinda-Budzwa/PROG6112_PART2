package wildliferescuesystem;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit Test Suite: RescueManagerTest (JUnit 4)
 */
public class RescueManagerTest {

    private RescueManager manager;
    private InjuredAnimalRescue injuredCase;
    private OrphanedAnimalRescue orphanedCase;
    private EndangeredSpeciesRescue endangeredCase;

    @Before
    public void setUp() {
        manager = new RescueManager();

        // 1. Injured Animal: (5 days * R1500) + R8000 vet + R5000 surgery = R20 500.00
        injuredCase = new InjuredAnimalRescue(
            "WR101", "Elephant Bull", "African Elephant", "Kruger",
            "John Ndlovu", 5, 1500.0, "Rescue in Progress",
            "Snare wound", 8000.0, true
        );

        // 2. Orphaned Animal: (10 days * R600) + R3000 feeding + R2500 foster = R11 500.00
        orphanedCase = new OrphanedAnimalRescue(
            "WR102", "Little Rhino", "White Rhino", "Hluhluwe",
            "Sarah Khoza", 10, 600.0, "Under Observation",
            4, 3000.0, true
        );

        // 3. Endangered Species: (4 days * R2000) + R10000 security + R8000 specialist = R26 000.00
        endangeredCase = new EndangeredSpeciesRescue(
            "WR103", "Pangolin", "Temminck's Pangolin", "Limpopo",
            "Peter Molefe", 4, 2000.0, "Pending",
            "Critically Endangered", 10000.0, true
        );

        manager.addRescueCase(injuredCase);
        manager.addRescueCase(orphanedCase);
    }

    @Test
    public void testRescueCostCalculations() {
        assertEquals("Injured case total cost calculation failed.", 20500.0, injuredCase.calculateTotalCost(), 0.001);
        assertEquals("Orphaned case total cost calculation failed.", 11500.0, orphanedCase.calculateTotalCost(), 0.001);
        assertEquals("Endangered case total cost calculation failed.", 26000.0, endangeredCase.calculateTotalCost(), 0.001);
    }

    @Test
    public void testRescuePriorityCalculations() {
        assertEquals("Injured case requiring surgery must be Critical.", "Critical", injuredCase.determinePriority());
        assertEquals("Orphaned case <= 6 months must be High priority.", "High", orphanedCase.determinePriority());
        assertEquals("Critically endangered species must be Critical.", "Critical", endangeredCase.determinePriority());
    }

    @Test
    public void testRescueStatusUpdates() {
        injuredCase.completeRescueOperation();
        assertEquals("Status should update to Completed.", "Completed", injuredCase.getCurrentRescueStatus());

        boolean updated = manager.updateRescueStatus("WR102", "Released");
        assertTrue("Status update should return true on existing ID.", updated);
        assertEquals("Status should reflect new value.", "Released", manager.searchRescueCase("WR102").getCurrentRescueStatus());
    }

    @Test
    public void testSearchExistingRescueCase() {
        RescueCase result = manager.searchRescueCase("WR101");
        assertNotNull("Search should return a RescueCase object.", result);
        assertEquals("Search result species should match.", "African Elephant", result.getSpecies());

        RescueCase notFound = manager.searchRescueCase("NON_EXISTENT_ID");
        assertNull("Searching an invalid ID should return null.", notFound);
    }

    @Test
    public void testPreventDuplicateRescueCaseId() {
        assertFalse("WR101 must not be considered unique.", manager.isCaseIdUnique("WR101"));

        InjuredAnimalRescue duplicateCase = new InjuredAnimalRescue(
            "WR101", "Lion", "African Lion", "Pilanesberg",
            "Ranger Mark", 3, 1000.0, "Pending", "Cut", 1500.0, false
        );

        boolean isAdded = manager.addRescueCase(duplicateCase);
        assertFalse("Adding a case with an existing ID must be rejected.", isAdded);
    }
}